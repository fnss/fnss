fnss.topologies.datacenter.three_tier_topology
==============================================

.. currentmodule:: fnss.topologies.datacenter

.. autofunction:: three_tier_topology