fnss.topologies.datacenter.DatacenterTopology.buffers
=====================================================

.. currentmodule:: fnss.topologies.datacenter

.. automethod:: DatacenterTopology.buffers