fnss.traffic.eventscheduling.read_event_schedule
================================================

.. currentmodule:: fnss.traffic.eventscheduling

.. autofunction:: read_event_schedule