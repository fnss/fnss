fnss.topologies.topology.Topology.remove_edge
=============================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: Topology.remove_edge