fnss.topologies.datacenter.DatacenterTopology.edges
===================================================

.. currentmodule:: fnss.topologies.datacenter

.. automethod:: DatacenterTopology.edges