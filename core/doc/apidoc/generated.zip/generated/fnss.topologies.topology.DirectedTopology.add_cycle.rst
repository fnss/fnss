fnss.topologies.topology.DirectedTopology.add_cycle
===================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.add_cycle