fnss.topologies.topology.Topology.size
======================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: Topology.size