fnss.topologies.datacenter.DatacenterTopology.add_cycle
=======================================================

.. currentmodule:: fnss.topologies.datacenter

.. automethod:: DatacenterTopology.add_cycle