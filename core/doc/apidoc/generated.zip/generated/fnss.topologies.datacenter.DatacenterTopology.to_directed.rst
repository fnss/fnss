fnss.topologies.datacenter.DatacenterTopology.to_directed
=========================================================

.. currentmodule:: fnss.topologies.datacenter

.. automethod:: DatacenterTopology.to_directed