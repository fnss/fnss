fnss.topologies.datacenter.DatacenterTopology.degree
====================================================

.. currentmodule:: fnss.topologies.datacenter

.. automethod:: DatacenterTopology.degree