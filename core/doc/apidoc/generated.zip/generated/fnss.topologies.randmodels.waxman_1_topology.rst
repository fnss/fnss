fnss.topologies.randmodels.waxman_1_topology
============================================

.. currentmodule:: fnss.topologies.randmodels

.. autofunction:: waxman_1_topology