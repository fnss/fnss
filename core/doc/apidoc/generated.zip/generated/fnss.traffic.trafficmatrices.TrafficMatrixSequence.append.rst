fnss.traffic.trafficmatrices.TrafficMatrixSequence.append
=========================================================

.. currentmodule:: fnss.traffic.trafficmatrices

.. automethod:: TrafficMatrixSequence.append