fnss.topologies.datacenter.DatacenterTopology.remove_edge
=========================================================

.. currentmodule:: fnss.topologies.datacenter

.. automethod:: DatacenterTopology.remove_edge