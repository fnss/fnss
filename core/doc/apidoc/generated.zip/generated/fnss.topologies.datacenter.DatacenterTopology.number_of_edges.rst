fnss.topologies.datacenter.DatacenterTopology.number_of_edges
=============================================================

.. currentmodule:: fnss.topologies.datacenter

.. automethod:: DatacenterTopology.number_of_edges