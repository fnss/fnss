fnss.topologies.topology.Topology.applications
==============================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: Topology.applications