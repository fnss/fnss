fnss.topologies.datacenter.DatacenterTopology.order
===================================================

.. currentmodule:: fnss.topologies.datacenter

.. automethod:: DatacenterTopology.order