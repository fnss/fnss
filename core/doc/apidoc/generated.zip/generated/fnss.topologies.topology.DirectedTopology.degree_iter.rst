fnss.topologies.topology.DirectedTopology.degree_iter
=====================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.degree_iter