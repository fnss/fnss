fnss.netconfig.weights.get_weights
==================================

.. currentmodule:: fnss.netconfig.weights

.. autofunction:: get_weights