fnss.netconfig.capacities.set_capacities_betweenness_gravity
============================================================

.. currentmodule:: fnss.netconfig.capacities

.. autofunction:: set_capacities_betweenness_gravity