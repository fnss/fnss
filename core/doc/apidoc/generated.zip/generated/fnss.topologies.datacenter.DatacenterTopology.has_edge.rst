fnss.topologies.datacenter.DatacenterTopology.has_edge
======================================================

.. currentmodule:: fnss.topologies.datacenter

.. automethod:: DatacenterTopology.has_edge