fnss.topologies.datacenter.DatacenterTopology.number_of_selfloops
=================================================================

.. currentmodule:: fnss.topologies.datacenter

.. automethod:: DatacenterTopology.number_of_selfloops