fnss.topologies.simplemodels.line_topology
==========================================

.. currentmodule:: fnss.topologies.simplemodels

.. autofunction:: line_topology