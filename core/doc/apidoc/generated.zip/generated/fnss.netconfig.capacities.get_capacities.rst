fnss.netconfig.capacities.get_capacities
========================================

.. currentmodule:: fnss.netconfig.capacities

.. autofunction:: get_capacities