fnss.topologies.parsers.parse_ashiip
====================================

.. currentmodule:: fnss.topologies.parsers

.. autofunction:: parse_ashiip