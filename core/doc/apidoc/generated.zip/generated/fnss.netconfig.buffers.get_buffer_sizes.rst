fnss.netconfig.buffers.get_buffer_sizes
=======================================

.. currentmodule:: fnss.netconfig.buffers

.. autofunction:: get_buffer_sizes