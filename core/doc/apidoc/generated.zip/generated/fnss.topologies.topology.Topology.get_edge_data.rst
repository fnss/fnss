fnss.topologies.topology.Topology.get_edge_data
===============================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: Topology.get_edge_data