fnss.topologies.datacenter.DatacenterTopology.applications
==========================================================

.. currentmodule:: fnss.topologies.datacenter

.. automethod:: DatacenterTopology.applications