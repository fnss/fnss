fnss.topologies.topology.Topology.clear
=======================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: Topology.clear