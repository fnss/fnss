fnss.traffic.trafficmatrices.TrafficMatrixSequence.get
======================================================

.. currentmodule:: fnss.traffic.trafficmatrices

.. automethod:: TrafficMatrixSequence.get