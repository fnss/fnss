fnss.topologies.topology.DirectedTopology.in_edges_iter
=======================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.in_edges_iter