fnss.netconfig.nodeconfig.add_stack
===================================

.. currentmodule:: fnss.netconfig.nodeconfig

.. autofunction:: add_stack