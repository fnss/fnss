fnss.topologies.topology.Topology.edges_iter
============================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: Topology.edges_iter