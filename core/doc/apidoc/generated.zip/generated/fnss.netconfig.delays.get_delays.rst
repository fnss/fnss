fnss.netconfig.delays.get_delays
================================

.. currentmodule:: fnss.netconfig.delays

.. autofunction:: get_delays