fnss.topologies.simplemodels.full_mesh_topology
===============================================

.. currentmodule:: fnss.topologies.simplemodels

.. autofunction:: full_mesh_topology