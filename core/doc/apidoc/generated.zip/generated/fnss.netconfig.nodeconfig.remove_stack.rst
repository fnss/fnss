fnss.netconfig.nodeconfig.remove_stack
======================================

.. currentmodule:: fnss.netconfig.nodeconfig

.. autofunction:: remove_stack