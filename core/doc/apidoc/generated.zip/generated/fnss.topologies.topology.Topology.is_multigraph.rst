fnss.topologies.topology.Topology.is_multigraph
===============================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: Topology.is_multigraph