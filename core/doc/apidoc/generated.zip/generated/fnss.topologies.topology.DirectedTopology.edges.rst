fnss.topologies.topology.DirectedTopology.edges
===============================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.edges