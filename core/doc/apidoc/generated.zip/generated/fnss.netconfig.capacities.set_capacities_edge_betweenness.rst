fnss.netconfig.capacities.set_capacities_edge_betweenness
=========================================================

.. currentmodule:: fnss.netconfig.capacities

.. autofunction:: set_capacities_edge_betweenness