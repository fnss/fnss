fnss.topologies.topology.Topology.degree
========================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: Topology.degree