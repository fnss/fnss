fnss.topologies.datacenter.DatacenterTopology.subgraph
======================================================

.. currentmodule:: fnss.topologies.datacenter

.. automethod:: DatacenterTopology.subgraph