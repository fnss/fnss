fnss.topologies.datacenter.bcube_topology
=========================================

.. currentmodule:: fnss.topologies.datacenter

.. autofunction:: bcube_topology