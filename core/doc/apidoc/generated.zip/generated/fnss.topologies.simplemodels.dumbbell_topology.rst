fnss.topologies.simplemodels.dumbbell_topology
==============================================

.. currentmodule:: fnss.topologies.simplemodels

.. autofunction:: dumbbell_topology