fnss.topologies.topology.Topology.name
======================================

.. currentmodule:: fnss.topologies.topology

.. autoattribute:: Topology.name