fnss.topologies.topology.Topology.number_of_nodes
=================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: Topology.number_of_nodes