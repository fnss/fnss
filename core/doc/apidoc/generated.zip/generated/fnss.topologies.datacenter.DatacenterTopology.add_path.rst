fnss.topologies.datacenter.DatacenterTopology.add_path
======================================================

.. currentmodule:: fnss.topologies.datacenter

.. automethod:: DatacenterTopology.add_path