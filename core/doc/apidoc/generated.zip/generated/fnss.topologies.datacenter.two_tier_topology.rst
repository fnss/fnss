fnss.topologies.datacenter.two_tier_topology
============================================

.. currentmodule:: fnss.topologies.datacenter

.. autofunction:: two_tier_topology