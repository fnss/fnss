fnss.topologies.simplemodels.k_ary_tree_topology
================================================

.. currentmodule:: fnss.topologies.simplemodels

.. autofunction:: k_ary_tree_topology