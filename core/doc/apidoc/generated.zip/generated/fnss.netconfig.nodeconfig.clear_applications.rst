fnss.netconfig.nodeconfig.clear_applications
============================================

.. currentmodule:: fnss.netconfig.nodeconfig

.. autofunction:: clear_applications