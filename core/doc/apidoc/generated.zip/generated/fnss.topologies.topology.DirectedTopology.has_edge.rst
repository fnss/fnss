fnss.topologies.topology.DirectedTopology.has_edge
==================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.has_edge