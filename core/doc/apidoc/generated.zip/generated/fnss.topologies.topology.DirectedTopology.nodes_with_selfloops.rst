fnss.topologies.topology.DirectedTopology.nodes_with_selfloops
==============================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.nodes_with_selfloops