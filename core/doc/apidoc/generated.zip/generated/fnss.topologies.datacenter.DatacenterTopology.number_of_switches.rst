fnss.topologies.datacenter.DatacenterTopology.number_of_switches
================================================================

.. currentmodule:: fnss.topologies.datacenter

.. automethod:: DatacenterTopology.number_of_switches