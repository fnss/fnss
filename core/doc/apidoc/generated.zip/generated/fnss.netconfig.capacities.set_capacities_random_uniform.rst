fnss.netconfig.capacities.set_capacities_random_uniform
=======================================================

.. currentmodule:: fnss.netconfig.capacities

.. autofunction:: set_capacities_random_uniform