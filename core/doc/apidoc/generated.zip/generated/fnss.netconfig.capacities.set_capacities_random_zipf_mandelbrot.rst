fnss.netconfig.capacities.set_capacities_random_zipf_mandelbrot
===============================================================

.. currentmodule:: fnss.netconfig.capacities

.. autofunction:: set_capacities_random_zipf_mandelbrot