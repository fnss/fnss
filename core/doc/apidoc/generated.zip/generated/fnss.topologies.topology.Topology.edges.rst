fnss.topologies.topology.Topology.edges
=======================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: Topology.edges