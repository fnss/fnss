fnss.topologies.parsers.parse_rocketfuel_isp_map
================================================

.. currentmodule:: fnss.topologies.parsers

.. autofunction:: parse_rocketfuel_isp_map