fnss.netconfig.weights.clear_weights
====================================

.. currentmodule:: fnss.netconfig.weights

.. autofunction:: clear_weights