fnss.traffic.trafficmatrices.TrafficMatrixSequence.insert
=========================================================

.. currentmodule:: fnss.traffic.trafficmatrices

.. automethod:: TrafficMatrixSequence.insert