fnss.topologies.datacenter.DatacenterTopology.delays
====================================================

.. currentmodule:: fnss.topologies.datacenter

.. automethod:: DatacenterTopology.delays