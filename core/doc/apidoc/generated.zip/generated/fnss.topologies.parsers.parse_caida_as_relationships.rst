fnss.topologies.parsers.parse_caida_as_relationships
====================================================

.. currentmodule:: fnss.topologies.parsers

.. autofunction:: parse_caida_as_relationships