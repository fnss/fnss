fnss.topologies.datacenter.DatacenterTopology.adjacency_list
============================================================

.. currentmodule:: fnss.topologies.datacenter

.. automethod:: DatacenterTopology.adjacency_list