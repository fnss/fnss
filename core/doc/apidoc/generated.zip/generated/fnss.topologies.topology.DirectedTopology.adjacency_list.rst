fnss.topologies.topology.DirectedTopology.adjacency_list
========================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.adjacency_list