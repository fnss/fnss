fnss.topologies.topology.Topology.degree_iter
=============================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: Topology.degree_iter