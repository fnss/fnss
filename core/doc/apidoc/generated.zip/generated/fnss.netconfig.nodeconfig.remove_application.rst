fnss.netconfig.nodeconfig.remove_application
============================================

.. currentmodule:: fnss.netconfig.nodeconfig

.. autofunction:: remove_application