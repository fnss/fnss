fnss.topologies.topology.DirectedTopology.delays
================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.delays