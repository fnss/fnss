fnss.topologies.datacenter.DatacenterTopology.adjacency_iter
============================================================

.. currentmodule:: fnss.topologies.datacenter

.. automethod:: DatacenterTopology.adjacency_iter