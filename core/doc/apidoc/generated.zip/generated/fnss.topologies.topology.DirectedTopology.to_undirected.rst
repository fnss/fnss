fnss.topologies.topology.DirectedTopology.to_undirected
=======================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.to_undirected