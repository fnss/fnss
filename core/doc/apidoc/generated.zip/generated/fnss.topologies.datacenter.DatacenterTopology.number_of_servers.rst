fnss.topologies.datacenter.DatacenterTopology.number_of_servers
===============================================================

.. currentmodule:: fnss.topologies.datacenter

.. automethod:: DatacenterTopology.number_of_servers