fnss.traffic.trafficmatrices.link_loads
=======================================

.. currentmodule:: fnss.traffic.trafficmatrices

.. autofunction:: link_loads