fnss.netconfig.capacities.set_capacities_pagerank_gravity
=========================================================

.. currentmodule:: fnss.netconfig.capacities

.. autofunction:: set_capacities_pagerank_gravity