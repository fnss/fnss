fnss.netconfig.nodeconfig.get_application_properties
====================================================

.. currentmodule:: fnss.netconfig.nodeconfig

.. autofunction:: get_application_properties