fnss.topologies.datacenter.DatacenterTopology.is_multigraph
===========================================================

.. currentmodule:: fnss.topologies.datacenter

.. automethod:: DatacenterTopology.is_multigraph