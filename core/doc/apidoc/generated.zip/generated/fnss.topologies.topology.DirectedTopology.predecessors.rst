fnss.topologies.topology.DirectedTopology.predecessors
======================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.predecessors