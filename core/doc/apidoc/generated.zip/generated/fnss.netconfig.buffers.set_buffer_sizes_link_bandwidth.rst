fnss.netconfig.buffers.set_buffer_sizes_link_bandwidth
======================================================

.. currentmodule:: fnss.netconfig.buffers

.. autofunction:: set_buffer_sizes_link_bandwidth