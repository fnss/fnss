fnss.topologies.datacenter.DatacenterTopology.add_star
======================================================

.. currentmodule:: fnss.topologies.datacenter

.. automethod:: DatacenterTopology.add_star