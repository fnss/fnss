fnss.netconfig.capacities.clear_capacities
==========================================

.. currentmodule:: fnss.netconfig.capacities

.. autofunction:: clear_capacities