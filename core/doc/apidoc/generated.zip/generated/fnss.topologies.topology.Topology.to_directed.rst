fnss.topologies.topology.Topology.to_directed
=============================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: Topology.to_directed