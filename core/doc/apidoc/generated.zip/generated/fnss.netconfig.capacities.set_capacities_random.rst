fnss.netconfig.capacities.set_capacities_random
===============================================

.. currentmodule:: fnss.netconfig.capacities

.. autofunction:: set_capacities_random