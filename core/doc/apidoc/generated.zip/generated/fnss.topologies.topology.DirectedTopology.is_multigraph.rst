fnss.topologies.topology.DirectedTopology.is_multigraph
=======================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.is_multigraph