fnss.topologies.topology.DirectedTopology.predecessors_iter
===========================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.predecessors_iter