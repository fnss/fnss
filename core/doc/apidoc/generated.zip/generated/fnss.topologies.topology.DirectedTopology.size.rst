fnss.topologies.topology.DirectedTopology.size
==============================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.size