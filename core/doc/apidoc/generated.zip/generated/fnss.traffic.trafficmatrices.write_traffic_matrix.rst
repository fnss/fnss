fnss.traffic.trafficmatrices.write_traffic_matrix
=================================================

.. currentmodule:: fnss.traffic.trafficmatrices

.. autofunction:: write_traffic_matrix