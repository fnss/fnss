fnss.topologies.topology.Topology.selfloop_edges
================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: Topology.selfloop_edges