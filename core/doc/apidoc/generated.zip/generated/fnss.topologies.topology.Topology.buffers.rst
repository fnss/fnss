fnss.topologies.topology.Topology.buffers
=========================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: Topology.buffers