fnss.topologies.topology.DirectedTopology.get_edge_data
=======================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.get_edge_data