fnss.topologies.topology.DirectedTopology.weights
=================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.weights