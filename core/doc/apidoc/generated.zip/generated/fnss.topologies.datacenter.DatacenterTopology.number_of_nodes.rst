fnss.topologies.datacenter.DatacenterTopology.number_of_nodes
=============================================================

.. currentmodule:: fnss.topologies.datacenter

.. automethod:: DatacenterTopology.number_of_nodes