fnss.topologies.datacenter.DatacenterTopology.neighbors_iter
============================================================

.. currentmodule:: fnss.topologies.datacenter

.. automethod:: DatacenterTopology.neighbors_iter