fnss.netconfig.get_buffer_sizes
===============================

.. currentmodule:: fnss.netconfig

.. autofunction:: get_buffer_sizes