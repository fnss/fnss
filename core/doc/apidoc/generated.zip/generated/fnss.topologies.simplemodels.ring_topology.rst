fnss.topologies.simplemodels.ring_topology
==========================================

.. currentmodule:: fnss.topologies.simplemodels

.. autofunction:: ring_topology