fnss.topologies.topology.Topology.to_undirected
===============================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: Topology.to_undirected