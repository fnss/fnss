fnss.traffic.eventscheduling.EventSchedule.number_of_events
===========================================================

.. currentmodule:: fnss.traffic.eventscheduling

.. automethod:: EventSchedule.number_of_events