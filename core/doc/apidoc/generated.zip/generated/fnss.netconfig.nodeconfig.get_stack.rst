fnss.netconfig.nodeconfig.get_stack
===================================

.. currentmodule:: fnss.netconfig.nodeconfig

.. autofunction:: get_stack