fnss.topologies.topology.DirectedTopology.nbunch_iter
=====================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.nbunch_iter