fnss.topologies.topology.write_topology
=======================================

.. currentmodule:: fnss.topologies.topology

.. autofunction:: write_topology