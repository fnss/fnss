fnss.topologies.topology.DirectedTopology.add_edge
==================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.add_edge