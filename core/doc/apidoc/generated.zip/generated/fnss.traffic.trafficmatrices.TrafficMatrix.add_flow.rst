fnss.traffic.trafficmatrices.TrafficMatrix.add_flow
===================================================

.. currentmodule:: fnss.traffic.trafficmatrices

.. automethod:: TrafficMatrix.add_flow