fnss.traffic.eventscheduling.poisson_process_event_schedule
===========================================================

.. currentmodule:: fnss.traffic.eventscheduling

.. autofunction:: poisson_process_event_schedule