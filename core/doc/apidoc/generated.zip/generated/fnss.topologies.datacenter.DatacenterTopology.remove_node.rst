fnss.topologies.datacenter.DatacenterTopology.remove_node
=========================================================

.. currentmodule:: fnss.topologies.datacenter

.. automethod:: DatacenterTopology.remove_node