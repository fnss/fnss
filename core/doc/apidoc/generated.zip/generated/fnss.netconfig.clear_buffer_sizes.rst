fnss.netconfig.clear_buffer_sizes
=================================

.. currentmodule:: fnss.netconfig

.. autofunction:: clear_buffer_sizes