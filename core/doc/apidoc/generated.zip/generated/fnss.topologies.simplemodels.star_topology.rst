fnss.topologies.simplemodels.star_topology
==========================================

.. currentmodule:: fnss.topologies.simplemodels

.. autofunction:: star_topology