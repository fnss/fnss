fnss.topologies.datacenter.DatacenterTopology.neighbors
=======================================================

.. currentmodule:: fnss.topologies.datacenter

.. automethod:: DatacenterTopology.neighbors