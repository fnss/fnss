fnss.topologies.topology.DirectedTopology.in_degree_iter
========================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.in_degree_iter