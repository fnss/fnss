fnss.netconfig.capacities.set_capacities_constant
=================================================

.. currentmodule:: fnss.netconfig.capacities

.. autofunction:: set_capacities_constant