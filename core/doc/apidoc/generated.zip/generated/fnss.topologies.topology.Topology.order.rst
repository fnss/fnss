fnss.topologies.topology.Topology.order
=======================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: Topology.order