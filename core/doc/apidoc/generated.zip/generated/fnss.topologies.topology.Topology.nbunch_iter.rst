fnss.topologies.topology.Topology.nbunch_iter
=============================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: Topology.nbunch_iter