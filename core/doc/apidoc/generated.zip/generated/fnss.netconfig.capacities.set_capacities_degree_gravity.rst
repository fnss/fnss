fnss.netconfig.capacities.set_capacities_degree_gravity
=======================================================

.. currentmodule:: fnss.netconfig.capacities

.. autofunction:: set_capacities_degree_gravity