fnss.topologies.randmodels.glp_topology
=======================================

.. currentmodule:: fnss.topologies.randmodels

.. autofunction:: glp_topology