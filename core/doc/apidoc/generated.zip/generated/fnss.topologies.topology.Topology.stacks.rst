fnss.topologies.topology.Topology.stacks
========================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: Topology.stacks