fnss.netconfig.delays.set_delays_geo_distance
=============================================

.. currentmodule:: fnss.netconfig.delays

.. autofunction:: set_delays_geo_distance