fnss.topologies.topology.Topology.number_of_selfloops
=====================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: Topology.number_of_selfloops