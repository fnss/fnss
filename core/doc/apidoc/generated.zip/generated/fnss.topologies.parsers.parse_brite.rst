fnss.topologies.parsers.parse_brite
===================================

.. currentmodule:: fnss.topologies.parsers

.. autofunction:: parse_brite