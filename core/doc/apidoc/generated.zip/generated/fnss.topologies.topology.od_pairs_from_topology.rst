fnss.topologies.topology.od_pairs_from_topology
===============================================

.. currentmodule:: fnss.topologies.topology

.. autofunction:: od_pairs_from_topology