fnss.topologies.topology.DirectedTopology.order
===============================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.order