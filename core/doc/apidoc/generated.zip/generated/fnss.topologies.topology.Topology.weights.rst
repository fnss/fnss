fnss.topologies.topology.Topology.weights
=========================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: Topology.weights