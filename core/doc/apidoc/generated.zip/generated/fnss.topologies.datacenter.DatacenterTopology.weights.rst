fnss.topologies.datacenter.DatacenterTopology.weights
=====================================================

.. currentmodule:: fnss.topologies.datacenter

.. automethod:: DatacenterTopology.weights