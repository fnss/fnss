fnss.topologies.topology.DirectedTopology.edges_iter
====================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.edges_iter