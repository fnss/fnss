fnss.traffic.eventscheduling.write_event_schedule
=================================================

.. currentmodule:: fnss.traffic.eventscheduling

.. autofunction:: write_event_schedule