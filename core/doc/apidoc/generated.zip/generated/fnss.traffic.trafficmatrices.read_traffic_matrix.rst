fnss.traffic.trafficmatrices.read_traffic_matrix
================================================

.. currentmodule:: fnss.traffic.trafficmatrices

.. autofunction:: read_traffic_matrix