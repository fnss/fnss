fnss.netconfig.delays.set_delays_constant
=========================================

.. currentmodule:: fnss.netconfig.delays

.. autofunction:: set_delays_constant