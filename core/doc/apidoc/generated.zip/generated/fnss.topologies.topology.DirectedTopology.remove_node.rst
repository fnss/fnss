fnss.topologies.topology.DirectedTopology.remove_node
=====================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.remove_node