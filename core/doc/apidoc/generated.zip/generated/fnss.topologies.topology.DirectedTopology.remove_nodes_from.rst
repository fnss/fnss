fnss.topologies.topology.DirectedTopology.remove_nodes_from
===========================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.remove_nodes_from