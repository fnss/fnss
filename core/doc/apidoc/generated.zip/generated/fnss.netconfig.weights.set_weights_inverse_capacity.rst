fnss.netconfig.weights.set_weights_inverse_capacity
===================================================

.. currentmodule:: fnss.netconfig.weights

.. autofunction:: set_weights_inverse_capacity