fnss.topologies.topology.DirectedTopology.copy
==============================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.copy