fnss.topologies.topology.read_topology
======================================

.. currentmodule:: fnss.topologies.topology

.. autofunction:: read_topology