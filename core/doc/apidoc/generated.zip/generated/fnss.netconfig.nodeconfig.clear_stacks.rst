fnss.netconfig.nodeconfig.clear_stacks
======================================

.. currentmodule:: fnss.netconfig.nodeconfig

.. autofunction:: clear_stacks