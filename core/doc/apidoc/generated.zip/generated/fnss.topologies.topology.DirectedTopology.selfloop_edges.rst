fnss.topologies.topology.DirectedTopology.selfloop_edges
========================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.selfloop_edges