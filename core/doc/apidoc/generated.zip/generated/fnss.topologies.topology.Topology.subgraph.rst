fnss.topologies.topology.Topology.subgraph
==========================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: Topology.subgraph