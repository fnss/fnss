fnss.topologies.datacenter.DatacenterTopology.add_edge
======================================================

.. currentmodule:: fnss.topologies.datacenter

.. automethod:: DatacenterTopology.add_edge