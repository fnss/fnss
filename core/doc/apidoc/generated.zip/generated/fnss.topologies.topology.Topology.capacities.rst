fnss.topologies.topology.Topology.capacities
============================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: Topology.capacities