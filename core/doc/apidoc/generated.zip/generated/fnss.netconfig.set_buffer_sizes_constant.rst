fnss.netconfig.set_buffer_sizes_constant
========================================

.. currentmodule:: fnss.netconfig

.. autofunction:: set_buffer_sizes_constant