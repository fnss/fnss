fnss.topologies.datacenter.DatacenterTopology.size
==================================================

.. currentmodule:: fnss.topologies.datacenter

.. automethod:: DatacenterTopology.size