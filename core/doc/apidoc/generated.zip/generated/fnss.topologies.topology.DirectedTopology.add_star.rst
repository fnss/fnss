fnss.topologies.topology.DirectedTopology.add_star
==================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.add_star