fnss.topologies.topology.DirectedTopology.capacities
====================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.capacities