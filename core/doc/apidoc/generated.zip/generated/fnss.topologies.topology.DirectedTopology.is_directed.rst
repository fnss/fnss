fnss.topologies.topology.DirectedTopology.is_directed
=====================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.is_directed