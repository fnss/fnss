fnss.topologies.topology.Topology.add_star
==========================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: Topology.add_star