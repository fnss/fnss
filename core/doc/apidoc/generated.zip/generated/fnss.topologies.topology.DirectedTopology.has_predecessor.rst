fnss.topologies.topology.DirectedTopology.has_predecessor
=========================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.has_predecessor