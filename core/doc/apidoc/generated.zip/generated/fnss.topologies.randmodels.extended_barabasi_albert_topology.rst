fnss.topologies.randmodels.extended_barabasi_albert_topology
============================================================

.. currentmodule:: fnss.topologies.randmodels

.. autofunction:: extended_barabasi_albert_topology