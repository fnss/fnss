fnss.netconfig.buffers.set_buffer_sizes_bw_delay_prod
=====================================================

.. currentmodule:: fnss.netconfig.buffers

.. autofunction:: set_buffer_sizes_bw_delay_prod