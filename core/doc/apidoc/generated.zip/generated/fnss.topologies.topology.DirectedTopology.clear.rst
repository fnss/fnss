fnss.topologies.topology.DirectedTopology.clear
===============================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.clear