fnss.topologies.topology.DirectedTopology.buffers
=================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.buffers