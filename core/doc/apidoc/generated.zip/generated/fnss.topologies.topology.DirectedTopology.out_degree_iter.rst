fnss.topologies.topology.DirectedTopology.out_degree_iter
=========================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.out_degree_iter