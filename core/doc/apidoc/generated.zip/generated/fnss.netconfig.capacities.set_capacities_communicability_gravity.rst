fnss.netconfig.capacities.set_capacities_communicability_gravity
================================================================

.. currentmodule:: fnss.netconfig.capacities

.. autofunction:: set_capacities_communicability_gravity