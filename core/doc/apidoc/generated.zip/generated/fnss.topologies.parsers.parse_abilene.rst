fnss.topologies.parsers.parse_abilene
=====================================

.. currentmodule:: fnss.topologies.parsers

.. autofunction:: parse_abilene