fnss.netconfig.delays.clear_delays
==================================

.. currentmodule:: fnss.netconfig.delays

.. autofunction:: clear_delays