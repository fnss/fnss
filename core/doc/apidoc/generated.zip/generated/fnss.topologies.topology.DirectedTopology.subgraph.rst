fnss.topologies.topology.DirectedTopology.subgraph
==================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.subgraph