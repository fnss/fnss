fnss.netconfig.capacities.set_capacities_random_zipf
====================================================

.. currentmodule:: fnss.netconfig.capacities

.. autofunction:: set_capacities_random_zipf