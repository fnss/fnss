fnss.traffic.trafficmatrices.stationary_traffic_matrix
======================================================

.. currentmodule:: fnss.traffic.trafficmatrices

.. autofunction:: stationary_traffic_matrix