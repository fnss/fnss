fnss.netconfig.buffers.clear_buffer_sizes
=========================================

.. currentmodule:: fnss.netconfig.buffers

.. autofunction:: clear_buffer_sizes