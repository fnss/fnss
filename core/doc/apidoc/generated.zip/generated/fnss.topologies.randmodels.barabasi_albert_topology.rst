fnss.topologies.randmodels.barabasi_albert_topology
===================================================

.. currentmodule:: fnss.topologies.randmodels

.. autofunction:: barabasi_albert_topology