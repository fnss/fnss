fnss.topologies.datacenter.DatacenterTopology.edges_iter
========================================================

.. currentmodule:: fnss.topologies.datacenter

.. automethod:: DatacenterTopology.edges_iter