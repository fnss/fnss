fnss.topologies.datacenter.DatacenterTopology.is_directed
=========================================================

.. currentmodule:: fnss.topologies.datacenter

.. automethod:: DatacenterTopology.is_directed