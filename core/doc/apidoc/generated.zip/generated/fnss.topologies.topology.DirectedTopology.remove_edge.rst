fnss.topologies.topology.DirectedTopology.remove_edge
=====================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.remove_edge