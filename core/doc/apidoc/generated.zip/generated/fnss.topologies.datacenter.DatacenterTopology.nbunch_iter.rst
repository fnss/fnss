fnss.topologies.datacenter.DatacenterTopology.nbunch_iter
=========================================================

.. currentmodule:: fnss.topologies.datacenter

.. automethod:: DatacenterTopology.nbunch_iter