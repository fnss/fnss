fnss.topologies.datacenter.DatacenterTopology.clear
===================================================

.. currentmodule:: fnss.topologies.datacenter

.. automethod:: DatacenterTopology.clear