fnss.topologies.topology.Topology.add_path
==========================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: Topology.add_path