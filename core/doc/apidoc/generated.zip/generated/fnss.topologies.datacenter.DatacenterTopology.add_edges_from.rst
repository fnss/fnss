fnss.topologies.datacenter.DatacenterTopology.add_edges_from
============================================================

.. currentmodule:: fnss.topologies.datacenter

.. automethod:: DatacenterTopology.add_edges_from