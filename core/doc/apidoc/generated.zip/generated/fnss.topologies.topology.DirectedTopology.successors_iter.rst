fnss.topologies.topology.DirectedTopology.successors_iter
=========================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.successors_iter