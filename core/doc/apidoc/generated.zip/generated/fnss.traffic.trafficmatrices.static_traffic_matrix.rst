fnss.traffic.trafficmatrices.static_traffic_matrix
==================================================

.. currentmodule:: fnss.traffic.trafficmatrices

.. autofunction:: static_traffic_matrix