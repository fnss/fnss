fnss.netconfig.weights.set_weights_constant
===========================================

.. currentmodule:: fnss.netconfig.weights

.. autofunction:: set_weights_constant