fnss.topologies.topology.DirectedTopology.applications
======================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.applications