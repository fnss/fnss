fnss.topologies.topology.DirectedTopology.degree
================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.degree