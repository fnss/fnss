fnss.topologies.datacenter.DatacenterTopology.to_undirected
===========================================================

.. currentmodule:: fnss.topologies.datacenter

.. automethod:: DatacenterTopology.to_undirected