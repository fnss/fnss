fnss.topologies.topology.DirectedTopology.number_of_nodes
=========================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.number_of_nodes