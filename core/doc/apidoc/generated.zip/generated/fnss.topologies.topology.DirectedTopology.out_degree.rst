fnss.topologies.topology.DirectedTopology.out_degree
====================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.out_degree