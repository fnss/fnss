fnss.topologies.topology.DirectedTopology.has_successor
=======================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.has_successor