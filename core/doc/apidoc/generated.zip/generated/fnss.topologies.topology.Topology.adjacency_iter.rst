fnss.topologies.topology.Topology.adjacency_iter
================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: Topology.adjacency_iter