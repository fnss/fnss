fnss.netconfig.weights.set_weights_delays
=========================================

.. currentmodule:: fnss.netconfig.weights

.. autofunction:: set_weights_delays