fnss.topologies.topology.fan_in_out_capacities
==============================================

.. currentmodule:: fnss.topologies.topology

.. autofunction:: fan_in_out_capacities