fnss.topologies.datacenter.DatacenterTopology.switches
======================================================

.. currentmodule:: fnss.topologies.datacenter

.. automethod:: DatacenterTopology.switches