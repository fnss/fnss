fnss.traffic.trafficmatrices.sin_cyclostationary_traffic_matrix
===============================================================

.. currentmodule:: fnss.traffic.trafficmatrices

.. autofunction:: sin_cyclostationary_traffic_matrix