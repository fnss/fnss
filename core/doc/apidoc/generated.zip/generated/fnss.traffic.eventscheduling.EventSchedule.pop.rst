fnss.traffic.eventscheduling.EventSchedule.pop
==============================================

.. currentmodule:: fnss.traffic.eventscheduling

.. automethod:: EventSchedule.pop