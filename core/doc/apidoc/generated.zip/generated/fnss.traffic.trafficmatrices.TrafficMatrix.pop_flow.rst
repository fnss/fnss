fnss.traffic.trafficmatrices.TrafficMatrix.pop_flow
===================================================

.. currentmodule:: fnss.traffic.trafficmatrices

.. automethod:: TrafficMatrix.pop_flow