fnss.topologies.datacenter.DatacenterTopology.capacities
========================================================

.. currentmodule:: fnss.topologies.datacenter

.. automethod:: DatacenterTopology.capacities