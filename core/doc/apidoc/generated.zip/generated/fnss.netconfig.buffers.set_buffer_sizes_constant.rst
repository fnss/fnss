fnss.netconfig.buffers.set_buffer_sizes_constant
================================================

.. currentmodule:: fnss.netconfig.buffers

.. autofunction:: set_buffer_sizes_constant