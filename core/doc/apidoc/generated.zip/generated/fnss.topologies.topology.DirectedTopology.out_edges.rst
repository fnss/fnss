fnss.topologies.topology.DirectedTopology.out_edges
===================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.out_edges