fnss.netconfig.capacities.set_capacities_edge_communicability
=============================================================

.. currentmodule:: fnss.netconfig.capacities

.. autofunction:: set_capacities_edge_communicability