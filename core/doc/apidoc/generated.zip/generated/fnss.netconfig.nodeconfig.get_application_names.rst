fnss.netconfig.nodeconfig.get_application_names
===============================================

.. currentmodule:: fnss.netconfig.nodeconfig

.. autofunction:: get_application_names