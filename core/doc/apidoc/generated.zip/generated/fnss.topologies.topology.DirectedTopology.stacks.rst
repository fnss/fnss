fnss.topologies.topology.DirectedTopology.stacks
================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.stacks