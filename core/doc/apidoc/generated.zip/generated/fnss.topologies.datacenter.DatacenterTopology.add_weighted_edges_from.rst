fnss.topologies.datacenter.DatacenterTopology.add_weighted_edges_from
=====================================================================

.. currentmodule:: fnss.topologies.datacenter

.. automethod:: DatacenterTopology.add_weighted_edges_from