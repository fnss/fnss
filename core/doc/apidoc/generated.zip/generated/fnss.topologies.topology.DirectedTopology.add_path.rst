fnss.topologies.topology.DirectedTopology.add_path
==================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.add_path