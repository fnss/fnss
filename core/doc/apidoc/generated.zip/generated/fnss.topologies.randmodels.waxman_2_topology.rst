fnss.topologies.randmodels.waxman_2_topology
============================================

.. currentmodule:: fnss.topologies.randmodels

.. autofunction:: waxman_2_topology