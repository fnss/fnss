fnss.topologies.parsers.parse_inet
==================================

.. currentmodule:: fnss.topologies.parsers

.. autofunction:: parse_inet