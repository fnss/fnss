fnss.traffic.trafficmatrices.TrafficMatrix.od_pairs
===================================================

.. currentmodule:: fnss.traffic.trafficmatrices

.. automethod:: TrafficMatrix.od_pairs