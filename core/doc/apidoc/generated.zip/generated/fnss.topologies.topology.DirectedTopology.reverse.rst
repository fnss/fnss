fnss.topologies.topology.DirectedTopology.reverse
=================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.reverse