fnss.traffic.trafficmatrices.TrafficMatrixSequence.pop
======================================================

.. currentmodule:: fnss.traffic.trafficmatrices

.. automethod:: TrafficMatrixSequence.pop