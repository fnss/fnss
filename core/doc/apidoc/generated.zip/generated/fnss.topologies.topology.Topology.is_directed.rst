fnss.topologies.topology.Topology.is_directed
=============================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: Topology.is_directed