fnss.topologies.datacenter.DatacenterTopology.selfloop_edges
============================================================

.. currentmodule:: fnss.topologies.datacenter

.. automethod:: DatacenterTopology.selfloop_edges