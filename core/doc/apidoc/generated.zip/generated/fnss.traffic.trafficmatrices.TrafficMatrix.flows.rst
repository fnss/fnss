fnss.traffic.trafficmatrices.TrafficMatrix.flows
================================================

.. currentmodule:: fnss.traffic.trafficmatrices

.. automethod:: TrafficMatrix.flows