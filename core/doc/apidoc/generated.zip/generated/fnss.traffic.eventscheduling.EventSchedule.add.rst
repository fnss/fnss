fnss.traffic.eventscheduling.EventSchedule.add
==============================================

.. currentmodule:: fnss.traffic.eventscheduling

.. automethod:: EventSchedule.add