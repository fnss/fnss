fnss.topologies.topology.DirectedTopology.name
==============================================

.. currentmodule:: fnss.topologies.topology

.. autoattribute:: DirectedTopology.name