fnss.topologies.datacenter.DatacenterTopology.get_edge_data
===========================================================

.. currentmodule:: fnss.topologies.datacenter

.. automethod:: DatacenterTopology.get_edge_data