fnss.netconfig.nodeconfig.add_application
=========================================

.. currentmodule:: fnss.netconfig.nodeconfig

.. autofunction:: add_application