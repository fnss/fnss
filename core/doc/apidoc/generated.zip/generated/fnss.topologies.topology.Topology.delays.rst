fnss.topologies.topology.Topology.delays
========================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: Topology.delays