fnss.topologies.datacenter.fat_tree_topology
============================================

.. currentmodule:: fnss.topologies.datacenter

.. autofunction:: fat_tree_topology