fnss.topologies.topology.DirectedTopology.in_degree
===================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.in_degree