fnss.topologies.topology.DirectedTopology.adjacency_iter
========================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.adjacency_iter