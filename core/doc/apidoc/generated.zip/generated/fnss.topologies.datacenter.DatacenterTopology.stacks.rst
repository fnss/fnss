fnss.topologies.datacenter.DatacenterTopology.stacks
====================================================

.. currentmodule:: fnss.topologies.datacenter

.. automethod:: DatacenterTopology.stacks