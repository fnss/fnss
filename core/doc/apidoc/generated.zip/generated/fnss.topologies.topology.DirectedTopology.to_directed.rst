fnss.topologies.topology.DirectedTopology.to_directed
=====================================================

.. currentmodule:: fnss.topologies.topology

.. automethod:: DirectedTopology.to_directed